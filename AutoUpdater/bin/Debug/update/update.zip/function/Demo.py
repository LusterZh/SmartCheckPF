from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import _init_paths

from Logger import system_log
from config import system_config

from Detection.train import Trainer
from Detection.detect.MCDetector import CenterNetDetector
from Classification.base_classifier import BaseClassifier

import os 
import time 
import argparse
import cv2 as cv 
import torch 

current_path = os.path.dirname(__file__)

parser = argparse.ArgumentParser(description="Demo")
parser.add_argument("Phase", help="train or test", type=str)
parser.add_argument("--train_folder", type=str)
parser.add_argument("--val_folder", default=None, type=str)
parser.add_argument("--num_class", default=1, type=int)
parser.add_argument("--detection_type", default="one_class_detection", type=str)
parser.add_argument("--model_root", type=str)
parser.add_argument("--version", type=str)
parser.add_argument("--test_img", default=None, type=str)
parser.add_argument("--model_path", default=None, type=str)
parser.add_argument("--use_gpu", action='store_true', default=False)
parser.add_argument("--test_folder", default=None, type=str)
parser.add_argument("--function_name", default=None, type=str)
parser.add_argument("--log_file", default="log.log", type=str)

args = parser.parse_args()

if __name__ == "__main__":
    phase = args.Phase
    log_root = os.path.join(current_path, "lib/Detection/log")
    if not os.path.exists(log_root):
        os.makedirs(log_root)

    if phase == "train":
        log_file_name = args.log_file
        train_folder = args.train_folder
        val_folder = args.val_folder
        version = args.version
        model_root = args.model_root
        num_class = args.num_class
        detection_type = args.detection_type

        log_file = os.path.join(log_root, log_file_name)
        system_log.set_filepath(log_file)

        trainer = Trainer("mbv3_CenterNet", num_class, detection_type, train_folder, model_root, validation_folder=val_folder, version=version)
        trainer.run()

    elif phase == "test":
        img_path = args.test_img
        model_path = args.model_path
        device = 'gpu' if args.use_gpu else 'cpu'

        if device == 'cpu':
            checkpoint = torch.load(model_path, map_location='cpu')
        else:
            checkpoint = torch.load(model_path)

        state_dict = checkpoint['state_dict']
        num_class = checkpoint['num_class']

        Detector = CenterNetDetector("mbv3_CenterNet", num_class, device, "test")
        version = Detector.load_model(state_dict)
        
        t1 = time.time()
        cv_img = cv.imread(img_path)
        result = Detector.run(cv_img)
        t2 = time.time()

        # write img
        # cv_img = cv.imread(img_path)
        for ret in result:
            bbox = ret["bbox"]
            score = ret["score"]
            cv.rectangle(cv_img, (int(bbox[0]), int(bbox[1])), (int(bbox[0]+bbox[3]), int(bbox[1]+bbox[2])), (0,0,255), thickness=2)
            cv.putText(cv_img, f"score={score:.2f}", (int(bbox[0]+5), int(bbox[1]+12)), cv.FONT_HERSHEY_SIMPLEX, 0.4, (0,0,255), thickness=1)

        cv.imwrite("result.jpg", cv_img)

        print(f"result = {result}, cost time: {(t2-t1):.8f}sec!")
    
    elif phase == "test_batch":
        test_folder = args.test_folder
        model_path = args.model_path
        log_file_name = args.log_file

        log_file = os.path.join(log_root, log_file_name)
        system_log.set_filepath(log_file)

        img_list = list(filter(lambda x: ".jpg" in x, os.listdir(test_folder)))
        img_len = len(img_list)

        Detector = BaseClassifier("test")
        version = Detector.load_model(model_path)
        acc = 0
        count = 0

        t1 = time.time()
        for i in range(img_len):
            img_path = os.path.join(test_folder, img_list[i])
            cv_img = cv.imread(img_path)
            result = Detector.predict(cv_img)
            print(f"test [{i+1}/{img_len}], img_path is {img_path}, result is {result}")
            if result == 1:
                count += 1
        
        t2 = time.time()
        acc = count / img_len 
        print(f"total is {img_len}, count: {count}, acc: {acc}, cost time: {(t2-t1):.8f}sec!")

    elif phase == "client":
        model_path = args.model_path
        function_name = args.function_name
        log_file_name = args.log_file

        log_file = os.path.join(log_root, log_file_name)
        system_log.set_filepath(log_file)

        classifier = BaseClassifier(function_name)
        version = classifier.load_model(model_path)
        print(f"version = {version}")





    
    