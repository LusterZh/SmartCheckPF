# 历史版本修改记录

* 20120/06/10　　　　`v2.0.4`

	1. 增加nms_kernel。
	2. generate_roi增加随机drift。

* 20120/06/09　　　　`v2.0.3`

	1. 更新配准1.4

* 20120/06/08　　　　`v2.0.2`

	1. Bug修复：修改one_class_mcdetector的predict函数所有情况result都返回1的bug。
	2. 修改voc2json的逻辑。
	3. 修改Demo的测试phase。

* 20120/06/05　　　　`v2.0.1`

	1. down_ration改成down_ratio。
	2. 增加批量resize文件
	3. voc2json增加down_ratio参数。

* 20120/06/04　　　　`v2.0.0`

	1. 客户端添加可选择性配准。
	2. 深度学习调度代码结构调整。增加扩展性。保存的pth文件增加部分字段。

* 20120/05/28　　　　`v1.0.9`

	1. Demo增加val的参数。
	2. client增加log。

* 20120/05/27　　　　`v1.0.8`

	1. 配准增加所有站参数。
	2. 训练增加数据增强。

* 20120/05/22　　　　`v1.0.7`

	1. 修改标注代码。
	2. 修改Demo文件代码。

* 20120/05/22　　　　`v1.0.6`

	1. 修改部分log描述。

* 20120/05/21　　　　`v1.0.5`

	1. fix bug: 客户端bug

* 20120/05/21　　　　`v1.0.4`

	1. 更新配准v1.3
	2. fix bug： 客户端接口H的ndarray修改成list。

* 20120/05/20　　　　`v1.0.3`

	1. 配准更新v1.2
	2. fix bug: base_detector.py中load time和img_path 不存在
	3. train.py 中加入model root 和 reverse参数。
	4. 更新demo.py
	5. 添加generate_roi.py文件。

* 20120/05/19　　　　`v1.0.2`

	1. server端增加计算H的接口

* 20120/05/19　　　　`v1.0.1`

	1. server rpc修改函数名

* 20120/05/19　　　　`v1.0`

	1. 初始更新版本

# Odyssey
李时珍Odyssey项目算法。包括SVM、CenterNet、配准、相似度计算等。

------------




### CenterNet
MobileNet v3 + CenterNet

### SVM
hog， lbp， rgb_hist， otsu等。

### CheckSimilar
similar = 0.31\*sift  + 0.25\*rgb_hist + 0.31\*hog + 0.13\*lbp



# environment

1. python3.6以上
2. opencv 3.4.2.16
3. opencv_contrib 3.4.2.16
4. pytorch 1.0以上
5. scikit-learn 0.21.2
6. scipy 1.3.0


# Reference
* [CenterNet](https://github.com/xingyizhou/CenterNet "CenterNet")
* [MobileNet v3](https://github.com/xiaolai-sqlai/mobilenetv3 "MobileNet v3")
* [DBFace](https://github.com/dlunion/DBFace "DBFace")

# Author
* [liuwei1023](https://github.com/liuwei1023 "liuwei1023")