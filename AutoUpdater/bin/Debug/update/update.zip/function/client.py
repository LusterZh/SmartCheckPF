from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import _init_paths

from Logger import system_log
from config import system_config

import json 
import requests
import os 
import cv2 as cv 
import numpy as np 
import traceback
import time 

from Classification.base_classifier import BaseClassifier
from Registration.Reg import Registration

current_path = os.path.dirname(__file__)

# define log file
log_folder = os.path.join(current_path, "log")
if not os.path.exists(log_folder):
    os.makedirs(log_folder)
log_path = os.path.join(log_folder, "client.log")
system_log.set_filepath(log_path)

# global variable
url = system_config.System["client_url"]
model_root = os.path.join(current_path, "model")
if not os.path.exists(model_root):
    os.makedirs(model_root)

reg1, reg2 = None, None 

roi_list = {}
function_list = {}

def post_request(url, json_data):
    data = json.dumps(json_data)
    requests.post(url, data)

################################################################
# interface
################################################################
def start(station, golden_sample_list):
    global reg1, reg2

    system_log.WriteLine(f"start...")

    if system_config._System["use_registration"] == True:
        reg1 = Registration(station[0], golden_sample_list[0])

        if len(station) == 2 and len(golden_sample_list) == 2:
            reg2 = Registration(station[1], golden_sample_list[1])
        system_log.WriteLine(f"Registration done, golden_sample_list: {golden_sample_list}")

    else:
        system_log.WriteLine(f"Do Not Use Registration.")

    return True

def stop():
    reg1 = None 
    reg2 = None 

    return True

def add_model(function_name, roi):
    global roi_list, function_list

    roi_list[function_name] = roi       # x,y,h,w
 
    model_folder = os.path.join(model_root, function_name)
    model_name = list(filter(lambda x: "model." in x, os.listdir(model_folder)))[0]
    model_path = os.path.join(model_folder, model_name)

    model = BaseClassifier(function_name)
    version = model.load_model(model_path)


    function_list[function_name] = model 

    # system_log.WriteLine(f"add model {function_name} done. model version is {version}")

    return version

def release_model(function_name):
    global roi_list, function_list

    roi_list.pop(function_name)
    function_list.pop(function_name)
    system_log.WriteLine(f"release function {function_name}")

    return True

def inference(img_path, inference_function_list, stat):
    '''stat: 0: zheng, 1: fan'''
    start = time.time()

    inference_function_list = [str(i) for i in inference_function_list]
    rtn = {}
    rtn["state"] = 1
    rtn["imgPath"] = img_path
    rtn["functionResult"] = []
    rtn["H"] = []

    cv_img = cv.imread(img_path)
    if cv_img is None:
        system_log.WriteLine(f"read image {img_path} ERROR, please check the path is correct.")
        rtn["state"] = 0
        post_request(url, rtn)
        return True 

    H = None
    if system_config._System["use_registration"] == True:
        # registration
        if stat == 0:
            reg = reg1 
            system_log.WriteLine(f"stat: 0, reg1")
        else:
            reg = reg2 
            system_log.WriteLine(f"stat: 1, reg2")
        # reg = reg1 if stat == 0 else reg2

        H = reg.getH(cv_img)
        try:
            H = H.tolist()
        except:
            H = None 

    rtn["H"] = H

    try:
        for function_name in inference_function_list:
            if function_name in function_list.keys():
                model = function_list[function_name]
                roi = roi_list[function_name]
                
                if system_config._System["use_registration"] == True:
                    _, new_roi = reg.getRoi(roi, H)     # new_roi: x,y,h,w                
                else:
                    new_roi = roi 

                x,y,h,w = new_roi
                patchs = cv_img[y:y+h, x:x+w]
                result = model.predict(patchs)      # pass: 1   fail: 0

                function_result = {}

                roi_json = {}
                roi_json['left']     = new_roi[0]
                roi_json["top"]      = new_roi[1]
                roi_json['right']    = new_roi[0] + new_roi[3]
                roi_json['bottom']   = new_roi[1] + new_roi[2]

                function_result['functionId'] = function_name
                function_result['IsFail'] = 1 - result
                function_result['roi'] = roi_json 

                rtn['functionResult'].append(function_result)         
            else:
                system_log.WriteLine(f"ERROR: fucntion {function_name} has not been loaded. please add model first.")

        end = time.time()
        system_log.WriteLine(f"predict image {img_path} done. cost time: {(end-start):.8f}sec!")

        post_request(url, rtn)
        system_log.WriteLine(f"post request: {rtn}")

    except:
        exstr = traceback.format_exc()
        system_log.WriteLine(f"{exstr}")

    return True 

