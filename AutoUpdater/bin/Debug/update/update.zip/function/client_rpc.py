# -*- coding:utf-8 -*-
""" Example of json-rpc usage with Wergzeug and requests.
NOTE: there are no Werkzeug and requests in dependencies of json-rpc.
NOTE: server handles all url paths the same way (there are no different urls).
# https://pypi.org/project/json-rpc/
"""

from werkzeug.wrappers import Request, Response
from werkzeug.serving import run_simple
from jsonrpc import JSONRPCResponseManager, dispatcher
from client import start, stop, add_model, release_model, inference
#from function.function import cut_image
import time
import socket

@Request.application
def application(request):
    dispatcher["start"] = lambda station, golden_sample_list:start(station, golden_sample_list)
    dispatcher["stop"] = lambda i:stopPython(i)
    dispatcher["add_model"] = lambda function_id, roi:add_model(function_id, roi)
    dispatcher["inference"] = lambda img_path,function_list:inference(img_path,function_list)
    dispatcher["release_model"] = lambda function_id:release_model(function_id)
   # dispatcher["cut_image"] = lambda img_path:cut_image(img_path)
   
    response = JSONRPCResponseManager.handle(
        request.get_data(cache=False, as_text=True), dispatcher)
    return Response(response.json, mimetype='application/json')


def stopPython(i):
    result = stop()
    return result;



if __name__ == '__main__':
    #myname = socket.getfqdn(socket.gethostname())
    myname = socket.gethostname()
    myaddr = socket.gethostbyname(myname)
    print ("myname:"+myname+"  myaddr: "+myaddr)
    #run_simple(myaddr, 4002, application)
    run_simple("0.0.0.0", 4002, application)


