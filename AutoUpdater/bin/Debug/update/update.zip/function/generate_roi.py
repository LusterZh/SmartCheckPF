from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import _init_paths

from Registration.Reg import Registration

import os
import cv2 as cv  
import random

def extract_roi(img, roi_rect):
    x,y,h,w = roi_rect
    roi = img[y:y+h, x:x+w]
    return roi


def mat_inter(box1,box2):
    x01, y01, x02, y02 = box1
    x11, y11, x12, y12 = box2
 
    lx = abs((x01 + x02) / 2 - (x11 + x12) / 2)
    ly = abs((y01 + y02) / 2 - (y11 + y12) / 2)
    sax = abs(x01 - x02)
    sbx = abs(x11 - x12)
    say = abs(y01 - y02)
    sby = abs(y11 - y12)
    if lx <= (sax + sbx) / 2 and ly <= (say + sby) / 2:
        return True
    else:
        return False


def random_crop(img, roi):
    h,w,c = img.shape
    x,y,roi_h,roi_w = roi 

    box1 = [x,y,x+roi_w,y+roi_h]


    new_x = 0
    new_y = 0

    while True:
        new_x = random.randint(0, w-roi_w)
        new_y = random.randint(0, h-roi_h)

        box2 = [new_x, new_y, new_x+roi_w, new_y+roi_h]
        if not mat_inter(box1, box2):
            break

    
    new_roi = [new_x, new_y, roi_h, roi_w]
    return new_roi

def random_drift(img, roi):
    drift_ratio = 0.035
    h,w,c = img.shape 
    x,y,roi_h,roi_w = roi

    max_drift_h = int(drift_ratio * roi_h)
    max_drift_w = int(drift_ratio * roi_w)

    while(True):
        drift_h = random.randint(-max_drift_h, max_drift_h)
        drift_w = random.randint(-max_drift_w, max_drift_w)

        new_x = x + drift_w
        new_y = y + drift_h

        if new_x > 0 and new_x + roi_w < w and new_y > 0 and new_y + roi_h < h:
            break
    
    new_roi = [new_x, new_y, roi_h, roi_w]

    return new_roi 
    

if __name__ == "__main__":
    phase = "test"
    station = "RightBoard1"
    funciton_name = "LDL_RightBoard1"
    golden_name = "Odyssey_PVT_A1_RightBoard1_CodeError_200608103342.jpg"
    golden = os.path.join("D:/ImageDataset/Odyssey/source_train/", golden_name)
    RandomCrop = True 
    RandomDrift = True 

    src_folder = "D:/ImageDataset/Odyssey/source_" + phase + "/" + station
    dst_folder = "D:/ImageDataset/Odyssey/patchs/"+ station +"/" + funciton_name + "/" + phase
    if not os.path.exists(dst_folder):
        os.makedirs(dst_folder)
    

    # roi_rect = [1777, 2137, 2536-2137, 2070-1777]           # Sensor_LeftBoard2
    # roi_rect = [2104, 1943, 2140-1943, 2311-2104]         # M2_LeftBoard1
    # roi_rect = [2730, 1512, 1778-1512, 3023-2730]           # M2_RightBoard1
    roi_rect = [2424, 1573, 1951-1573, 2773-2424]           # LDL_RightBoard1

    


    reg = Registration(station, golden)

    for img_name in filter(lambda x: ".jpg" in x, os.listdir(src_folder)):
        img_path = os.path.join(src_folder, img_name)
        dst_path = os.path.join(dst_folder, img_name)
        cv_img = cv.imread(img_path)
        H = reg.getH(cv_img)

        if RandomDrift and random.randint(0,2) == 1:
            # random drift
            roi_rect = random_drift(cv_img, roi_rect)

        _, new_roi = reg.getRoi(roi_rect, H)

        patchs = extract_roi(cv_img, new_roi)
        cv.imwrite(dst_path, patchs)

        if RandomCrop == True:
            random_roi = random_crop(cv_img, new_roi)
            random_patchs = extract_roi(cv_img, random_roi)
            random_dst_path = os.path.join(dst_folder, img_name.split(".")[0]+"_random.jpg")
            cv.imwrite(random_dst_path, random_patchs)

        print(f"write image to {dst_path}")

