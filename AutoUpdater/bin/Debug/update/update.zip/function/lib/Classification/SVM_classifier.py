from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from SVM.svm_model import SVMModel

from Logger import system_log

class SVMClassifier(object):
    def __init__(self, function_name):
        self.model = SVMModel(function_name)

    def load_model(self, model_path):
        version = self.model.load_model(model_path, return_version=True) 
        return version 

    def predict(self, cv_img):
        result = self.model.predict(cv_img)

        if result == 1:     # pass: 1   fail: 0
            return 1
        else:
            return 0 