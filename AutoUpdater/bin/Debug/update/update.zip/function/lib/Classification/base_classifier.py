from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from Logger import system_log
from .SVM_classifier import SVMClassifier
from .factory_detection_classifier import FactoryDetectionClassifier


import traceback

_classification_factory = {
    "m": SVMClassifier,
    "pth": FactoryDetectionClassifier
}

def get_classifier(model_suffix):
    return _classification_factory[model_suffix]

class BaseClassifier(object):
    def __init__(self, funciton_name):
        self.model = None 
        self.funciton_name = funciton_name

    def load_model(self, model_path):
        try:
            model_suffix = model_path.split(".")[-1]
            classifier = get_classifier(model_suffix)
            self.model = classifier(self.funciton_name)

            version = self.model.load_model(model_path)

            return version 

        except:
            exstr = traceback.format_exc()
            system_log.WriteLine(f"{exstr}")
            return None 

    def predict(self, cv_img):
        result = self.model.predict(cv_img)

        if result == 1:     # pass: 1   fail: 0
            return 1
        else:
            return 0

