from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from config import system_config
from Logger import system_log

import torch 
import traceback

from .one_class_mcdetector import OneClassMCDetector

factory_Detection = {
    "one_class_detection": OneClassMCDetector
}


class FactoryDetectionClassifier(object):
    def __init__(self, function_name):
        self.model = None 
        self.function_name = function_name

    def load_model(self, model_path):
        try:
            device = 'gpu' if system_config._Detector["use_gpu"] else 'cpu'
                
            if device == 'cpu':
                checkpoint = torch.load(model_path, map_location='cpu')
            else:
                checkpoint = torch.load(model_path)


            detection_type = checkpoint['detection_type']
            model_name = checkpoint["model_name"]
            version = checkpoint['version']
            epoch = checkpoint['epoch']
            state_dict = checkpoint['state_dict']
            num_class = checkpoint['num_class']

            self.model = factory_Detection[detection_type](model_name, num_class, device, self.function_name)
            self.model.load_model(state_dict)

            system_log.WriteLine(f"[{self.function_name}]   load Deep learning model done. detection_type: {detection_type}, model_name: {model_name}, num_class: {num_class}, epoch: {epoch}, version: {version}, device: {device}")

            return version
        except:
            exstr = traceback.format_exc()
            system_log.WriteLine(f"{exstr}")
            return None 

    def predict(self, cv_img):
        result = self.model.predict(cv_img)

        return result 