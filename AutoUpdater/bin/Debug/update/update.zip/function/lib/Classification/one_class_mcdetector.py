from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from Detection.detect.MCDetector import CenterNetDetector

class OneClassMCDetector(object):
    def __init__(self, model_name, num_class, device='cpu', function_name=None):
        self.model = CenterNetDetector(model_name, num_class, device, function_name)

    def load_model(self, state_dict):
        self.model.load_model(state_dict)

    def predict(self, cv_img):
        result = self.model.run(cv_img) 
        if len(result) > 0:
            ret = 1
        else:
            ret = 0

        return ret          # pass: 1   fail: 0