import os 
import cv2 as cv 

input_folder = "D:/ImageDataset/Odyssey/source_train/MainBoard2"
dst_folder = "D:/ImageDataset/Odyssey/source_train/down_ratio"

if not os.path.exists(dst_folder):
    os.makedirs(dst_folder)

down_ratio = 4 

for img_name in filter(lambda x: ".jpg" in x, os.listdir(input_folder)):
    img_path = os.path.join(input_folder, img_name)
    dst_path = os.path.join(dst_folder, img_name)

    cv_img = cv.imread(img_path)
    dst_img = cv.resize(cv_img, (0,0), fx=1 / down_ratio, fy=1 / down_ratio, interpolation=cv.INTER_AREA)

    cv.imwrite(dst_path, dst_img)
    print(f"write image to {dst_path}")
