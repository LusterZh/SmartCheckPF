import os 
import json 
from xml.dom.minidom import parse
import xml.dom.minidom
import cv2 as cv 

img_folder = "D:/ImageDataset/Odyssey/patchs/RightBoard1/LDL_RightBoard1/test"
xml_folder = "D:/ImageDataset/Odyssey/patchs/RightBoard1/LDL_RightBoard1/anns"
json_folder = "D:/ImageDataset/Odyssey/patchs/RightBoard1/LDL_RightBoard1/test"

cls_json = {
    "LDL": 0
}

down_ratio = 1

if not os.path.exists(json_folder):
    os.makedirs(json_folder)



for img_name in filter(lambda x: ".jpg" in x, os.listdir(img_folder)):
    file_name = img_name.split(".")[0]
    xml_path = os.path.join(xml_folder, file_name+".xml")
    json_path = os.path.join(json_folder, file_name+".json")
    img_path = os.path.join(img_folder, img_name)

    cv_img = cv.imread(img_path)
    height,width,c = cv_img.shape

    dst_json = {}
    dst_json['img_path'] = img_name
    dst_json['width'] = int(width / down_ratio)
    dst_json['height'] = int(height / down_ratio)
    anns = []

    if os.path.exists(xml_path):
        DOMTree = xml.dom.minidom.parse(xml_path)
        root = DOMTree.documentElement 

        objects = root.getElementsByTagName('object')
        for obj in objects:
            name = obj.getElementsByTagName('name')[0].childNodes[0].data.strip("\n")
            bndbox = obj.getElementsByTagName('bndbox')[0]
            xmin = float(bndbox.getElementsByTagName('xmin')[0].childNodes[0].data.strip("\n")) / down_ratio
            xmax = float(bndbox.getElementsByTagName('xmax')[0].childNodes[0].data.strip("\n")) / down_ratio
            ymin = float(bndbox.getElementsByTagName('ymin')[0].childNodes[0].data.strip("\n")) / down_ratio
            ymax = float(bndbox.getElementsByTagName('ymax')[0].childNodes[0].data.strip("\n")) / down_ratio

            anns_json = {}
            bbox = [int(xmin), int(ymin), int(ymax-ymin), int(xmax-xmin)]
            cls_id = cls_json[name]
            anns_json['bbox'] = bbox
            anns_json['cls_id'] = cls_id
            anns.append(anns_json)

    dst_json['anns'] = anns

    with open(json_path, 'w') as f:
        json.dump(dst_json, f, indent=4)
    print(f"write json file to {json_path}")