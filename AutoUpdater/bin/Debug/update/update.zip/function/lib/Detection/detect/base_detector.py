from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from Logger import system_log

import cv2 as cv 
import numpy as np 
import torch 
import time 
import traceback

from Detection.models.model import create_model

class BaseDetector(object):
    def __init__(self, model_name, num_class, device='cpu', function_name=None):
        try:
            self.model = create_model(model_name, num_class)
            
            self.device = device
            self.function_name = function_name
        
        except:
            exstr = traceback.format_exc()
            system_log.WriteLine(f"{exstr}")

    def load_model(self, state_dict):
        try:
            self.model.load_state_dict(state_dict)
            if self.device == "gpu":
                self.model = self.model.cuda()

            self.model.eval()

        except:
            exstr = traceback.format_exc()
            system_log.WriteLine(f"{exstr}")

    def pre_process(self, image):
        image = image.astype(np.float32).transpose(2,0,1)
        image_tensor = torch.Tensor(image/255.)
        image_tensor = torch.unsqueeze(image_tensor, 0)

        if self.device == "gpu":
            image_tensor = image_tensor.cuda()
        
        return image_tensor

    def get_version(self):
        return self.version

    def get_reverse(self):
        return self.reverse


    def process(self, tensor):
        raise NotImplementedError

    def merge_output(self, dets):
        raise NotImplementedError

    def run(self, cv_img):
        pre_time, forward_time, merge_time, total_time = 0, 0, 0, 0

        start_time = time.time()
        result = []

        if cv_img is not None:
            input_tensor = self.pre_process(cv_img)
            preprocess_time = time.time()
            pre_time = preprocess_time - start_time

            output_tensor = self.process(input_tensor).detach()
            net_forward_time = time.time()
            forward_time = net_forward_time-preprocess_time

            result = self.merge_output(output_tensor)       # result: [{"bbox":[x,y,h,w], "score":score, "cls_id":cls_id}, ...]
            merged_time = time.time()
            merge_time = merged_time - net_forward_time
            total_time = merged_time - start_time


        else:
            system_log.WriteLine(f"[{self.function_name}]  ERROR: read image fail. please check if the path is correct.")


        system_log.WriteLine(f"[{self.function_name}]  Deep learning predict done, "
                             f"preprocess_time: {pre_time:.8f}sec, net_forward_time: {forward_time:.8f}sec, "
                             f"merge_output_time: {merge_time:.8f}sec,  total time: {total_time:.8f}sec")
        return result

