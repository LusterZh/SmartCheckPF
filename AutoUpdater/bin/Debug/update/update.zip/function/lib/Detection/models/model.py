from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from Logger import system_log
from config import system_config


import torchvision.models as models
import torch
import torch.nn as nn
import os
import time 

from .networks.MCNet import get_MobileNet_CenterNet_model as get_MCModel

_model_factory = {
    "mbv3_CenterNet": get_MCModel
}

def create_model(model_name, num_class):
    start = time.time()
    get_model =_model_factory[model_name]
    model = get_model(num_class)
    end = time.time()

    # system_log.WriteLine(f"create model {model_name}, cost time: {(end-start):.8f}sec!")
    return model


def save_model(path, epoch, model, model_name, num_class, detection_type, version=None):
    if isinstance(model, torch.nn.DataParallel):
        state_dict = model.module.state_dict()
    else:
        state_dict = model.state_dict()
    data = {
        "detection_type": detection_type,
        "model_name": model_name,
        "version": version,
        "epoch": epoch,
        "state_dict": state_dict,
        "num_class": num_class
    }

    torch.save(data, path)
    system_log.WriteLine(f"save model to {path}")



    




