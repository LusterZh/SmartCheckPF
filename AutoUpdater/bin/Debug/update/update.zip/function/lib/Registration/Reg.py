# Reg v 1.6
# do not support rotation
# MainBoard 1 & 2, LeftBoard 1 & 2, RightBoard 1 & 2, Imagers
import cv2
import numpy as np
import threading
import queue
import math
from functools import reduce
# from tqdm import tqdm
from skimage import exposure
import os

MainBoard1 = {
	'boxes' : [[3215, 3829, 350, 350], [1536, 881, 350, 350], [1354, 3838, 350, 350], [818, 3831, 350, 350], [622, 2640, 350, 350]],
	'minRadius' : [40, 40, 40, 40, 20],
	'maxRadius' : [60, 60, 60, 60, 50],
	'param1' : 50,
	'param2' : 30	
}

MainBoard2 = {
	'boxes' : [[3300, 3900, 250, 250], [3300, 973, 250, 250], [714, 2386, 300, 300], [833, 908, 300, 300]],
	'minRadius' : [30, 25, 25, 30],
	'maxRadius' : [45, 45, 40, 45],
	'param1' : 50,
	'param2' : 25
}

LeftBoard1 = {
	'boxes' : [[2249, 2843, 300, 300], [1900, 2084, 300, 300], [1515, 2196, 300, 300]],
	'minRadius' : [20, 20, 20],
	'maxRadius' : [60, 40, 60],
	'param1' : 100,
	'param2' : [30, 50, 30]
}

LeftBoard2 = {
	'boxes' : [[1485, 2125, 200, 200], [1500, 2983, 250, 250], [1713, 2209, 250, 250], [1905, 2002, 250, 250]],
	'minRadius' : [40, 25, 30, 25],
	'maxRadius' : [55, 40, 45, 50],
	'param1' : 55,
	'param2' : 30
}

RightBoard1 = {
    'boxes' : [[1934, 2696, 300, 300], [1508, 2723, 300, 300], [2312, 2159, 300, 300]],
	'minRadius' : [20, 20, 15],
	'maxRadius' : [30, 35, 25],
	'param1' : 50,
	'param2' : 25
}

RightBoard2 = {
	'boxes' : [[2632, 2133, 300, 300], [1948, 2696, 300, 300], [1491, 2155, 300, 300], [1326, 2326, 300, 300]],
	'minRadius' : [20, 20, 30, 20],
	'maxRadius' : [30, 35, 40, 30],
	'param1' : 50,
	'param2' : 25
}

Imagers = {
	'boxes' : [[2400, 3241, 600, 600], [1823, 2538, 300, 300], [2515, 1925, 409, 400]],#, [2515, 2092, 300, 300]],
	'minRadius' : [25, 30, 45],#, 10],
	'maxRadius' : [35, 40, 55],#, 20],
	'param1' : 60,
	'param2' : 25
}

BaseBracket = {
	'boxes' : [[2400, 3241, 600, 600], [1823, 2538, 300, 300], [2515, 1925, 409, 400]],#, [2515, 2092, 300, 300]],
	'minRadius' : [25, 30, 45],#, 10],
	'maxRadius' : [35, 40, 55],#, 20],
	'param1' : 60,
	'param2' : 25
}

BoardinHSG = {
	'boxes' : [[2400, 3241, 600, 600], [1823, 2538, 300, 300], [2515, 1925, 409, 400]],#, [2515, 2092, 300, 300]],
	'minRadius' : [25, 30, 45],#, 10],
	'maxRadius' : [35, 40, 55],#, 20],
	'param1' : 60,
	'param2' : 25
}

ChassisScrews = {
	'boxes' : [[2400, 3241, 600, 600], [1823, 2538, 300, 300], [2515, 1925, 409, 400]],#, [2515, 2092, 300, 300]],
	'minRadius' : [25, 30, 45],#, 10],
	'maxRadius' : [35, 40, 55],#, 20],
	'param1' : 60,
	'param2' : 25
}

CLILens = {
	'boxes' : [[2400, 3241, 600, 600], [1823, 2538, 300, 300], [2515, 1925, 409, 400]],#, [2515, 2092, 300, 300]],
	'minRadius' : [25, 30, 45],#, 10],
	'maxRadius' : [35, 40, 55],#, 20],
	'param1' : 60,
	'param2' : 25
}

FlipChassis = {
	'boxes' : [[2400, 3241, 600, 600], [1823, 2538, 300, 300], [2515, 1925, 409, 400]],#, [2515, 2092, 300, 300]],
	'minRadius' : [25, 30, 45],#, 10],
	'maxRadius' : [35, 40, 55],#, 20],
	'param1' : 60,
	'param2' : 25
}

HingeHousing1 = {
	'boxes' : [[2400, 3241, 600, 600], [1823, 2538, 300, 300], [2515, 1925, 409, 400]],#, [2515, 2092, 300, 300]],
	'minRadius' : [25, 30, 45],#, 10],
	'maxRadius' : [35, 40, 55],#, 20],
	'param1' : 60,
	'param2' : 25
}

HingeHousing2 = {
	'boxes' : [[2400, 3241, 600, 600], [1823, 2538, 300, 300], [2515, 1925, 409, 400]],#, [2515, 2092, 300, 300]],
	'minRadius' : [25, 30, 45],#, 10],
	'maxRadius' : [35, 40, 55],#, 20],
	'param1' : 60,
	'param2' : 25
}

UnitsClosed = {
	'boxes' : [[2400, 3241, 600, 600], [1823, 2538, 300, 300], [2515, 1925, 409, 400]],#, [2515, 2092, 300, 300]],
	'minRadius' : [25, 30, 45],#, 10],
	'maxRadius' : [35, 40, 55],#, 20],
	'param1' : 60,
	'param2' : 25
}

MainDisplay = {
	'boxes' : [[2400, 3241, 600, 600], [1823, 2538, 300, 300], [2515, 1925, 409, 400]],#, [2515, 2092, 300, 300]],
	'minRadius' : [25, 30, 45],#, 10],
	'maxRadius' : [35, 40, 55],#, 20],
	'param1' : 60,
	'param2' : 25
}

class Reg(object):
    	
	def __init__(self, golden, boxes=None, minRadius=None, maxRadius=None, param1=50, param2=30):

		for k, v in filter(lambda k : k[0] != 'self' and k[0] != 'golden', locals().items()):
			self.__setattr__(k, v)
		if not isinstance(self.param1, list):
			self.param1 = [self.param1] * len(boxes)
		if not isinstance(self.param2, list):
			self.param2 = [self.param2] * len(boxes)
		if golden is not None:
			self.gcnts, _ = self.getCnts(golden, self.boxes)
			self.gcnts = np.array(self.gcnts).reshape(-1, 1, 2)
			golden = None

	@staticmethod
	def roiConvert(roi):
		return (*roi[:2][::-1], *roi[2:])

	@staticmethod
	def affineTransform(point, H):

		(a1, b1, c1, a2, b2, c2), (x, y) = H.reshape(-1), point
		ax = a1 * x + b1 * y + c1
		ay = a2 * x + b2 * y + c2
		return (int(max(ax, 0)), int(max(ay, 0)))

	def getCnts(self, img, boxes):
		cnts, stats = [], np.array([False] * len(boxes))
		for idx, box in enumerate(boxes):
			x, y, w, h = box
			chunk = cv2.cvtColor(cv2.medianBlur(img[x : x + w, y : y + h], 5), cv2.COLOR_BGR2GRAY)
			cnt = cv2.HoughCircles(chunk, cv2.HOUGH_GRADIENT, 1, max(w, h), minRadius=self.minRadius[idx], maxRadius=self.maxRadius[idx], param1=self.param1[idx], param2=self.param2[idx])
			if cnt is not None:
				cnt, radius = np.float32(cnt.reshape(-1)[:2][::-1]), np.float(cnt.reshape(-1)[-1])
				if not (cnt == np.array([0, 0], dtype=np.float32)).all():
					cnts.append(cnt + np.array([x, y], dtype=np.float32))
					stats[idx] = True

		return cnts, stats

	def getH(self, image):
		cnts, stats = self.getCnts(image, self.boxes)
		if len(cnts) < 3: return None
		cnts = np.array(cnts).reshape(-1, 1, 2)
		try:
			gcnts = self.gcnts[stats]
			H = cv2.estimateRigidTransform(gcnts, cnts, fullAffine=False)
			return H
		except:
			return None

class Registration(Reg):
    
	def __init__(self, station, golden=None):
		settings = globals()[station]
		if golden is not None:
			golden = cv2.imread(golden)
			super(Registration, self).__init__(golden, **settings)

	def getRoi(self, roi, H):
		if H is None:
			return False, roi
		try:
			x, y, w, h = Reg.roiConvert(roi)
			H = np.array(H, dtype=np.float32)
			points = np.array([self.affineTransform(p, H) for p in [[x, y], [x, y + h], [x + w, y], [x + w, y + h]]])
			minx, miny, maxx, maxy = np.min(points[:, 0]), np.min(points[:, 1]), np.max(points[:, 0]), np.max(points[:, 1])
			cx, cy = (minx + maxx) / 2, (miny + maxy) / 2
			x, y, w, h = int(max(cx - w / 2, 0)), int(max(cy - h / 2, 0)), w, h
			return True, Reg.roiConvert((x, y, w, h))
		except: 
			return False, roi

# multi-threading processing functions
def multiThreadingProcess(rets, params, function, workers=50, flag=False):
	q = queue.Queue(workers)
	# params = tqdm(params) if flag else params
	for tid, param in enumerate(params):
		t = threading.Thread(target=function, args=(rets, tid, *param))
		t.start()
		q.put(t)
		if q.full():
			while not q.empty():
				t = q.get()
				t.join()
	while not q.empty():
		t = q.get()
		t.join()

	return rets

def registration_extract_rois(station, Hs, roi, workers=50):
	reg = Registration(station)
	rets = [roi] * len(Hs)
	params = ([reg, H, roi] for H in Hs)
	return multiThreadingProcess(rets, params, registration_extract_rois_unit, workers=workers)

def registration_extract_rois_unit(rois, tid, reg, H, roi_rect):
	_, roi = reg.getRoi(roi_rect, H)
	rois[tid] = list(roi)

def registration_extract_Hs(station, golden, imagePaths, workers=50):
	reg = Registration(station, golden)
	rets = [None] * len(imagePaths)
	params = ([reg, imagePath] for imagePath in imagePaths)
	return multiThreadingProcess(rets, params, registration_extract_Hs_unit, workers=workers)

def registration_extract_Hs_unit(Hs, tid, reg, imagePath):
	image = cv2.imread(imagePath)
	H = reg.getH(image)
	try: 
		H = H.tolist()
		Hs[tid] = H
	except:
		pass

def registration_extract_Cnts(station, golden, imagePaths, resdir, workers=50):
	reg = Registration(station, golden)
	rets = [None] * len(imagePaths)
	params = ([reg, imagePath, station, resdir] for imagePath in imagePaths)
	return multiThreadingProcess(rets, params, registration_extract_Cnts_unit, workers=workers)


def registration_extract_Cnts_unit(cnts, tid, reg, imagePath, station, resdir):
	name = imagePath.split('/')[-1].split('.')[0]
	image = cv2.imread(imagePath)
	cnts = reg.getCnts(image, reg.boxes)[0]
	
	boxes = np.array(reg.boxes)
	cuts, boxes = np.int32(cnts), np.int32(boxes)
	for cnt in cnts:
		y, x = cnt
		image = cv2.circle(image, (int(x), int(y)), 1, (0, 0, 255), thickness=20)
	for box in boxes:
		x, y, w, h = box
		image = cv2.rectangle(image, (y, x), (y + h, x + w), (255, 0, 0), thickness=10)
	image = cv2.resize(image, None, fx=0.25, fy=0.25)
	cv2.imwrite(f'{resdir}/{name}_1.jpg', image)

def test_unit(mark, **params):
	rets = globals()[f'registration_extract_{mark}s'](**params)
	return rets

def ALL_TESTING(station, golden, imgs, save_dir, roi, workers):
	CNT_param = {
		'golden' : golden,
		'station' : station,
		'imagePaths' : imgs,
		'workers' : workers,
		'resdir' : save_dir
	}

	H_param = {
		'golden' : golden,
		'station' : station,
		'imagePaths' : imgs,
		'workers' : workers
	}
	print ('test Cnts')
	test_unit('Cnt', **CNT_param)
	print ('testing Hs')
	Hs = test_unit('H', **H_param)
	roi_param = {
		'station' : station,
		'Hs' : Hs,
		'roi' : roi,
		'workers' : workers
	}
	print ('testing ROIs')
	ROIs = test_unit('roi', **roi_param)
	for image, ROI in zip(imgs, ROIs):
		name = image.split('/')[-1].split('.')[0]
		image = cv2.imread(image)
		x, y, w, h = Reg.roiConvert(ROI)
		cv2.imwrite(f'{save_dir}/{name}.jpg', image[x : x + w, y : y + h])